Visit [the site](https://movie-app-nine-sooty.vercel.app/)

- next.js
- react.js
- axios
- zustand

for API: rapidapi.com
